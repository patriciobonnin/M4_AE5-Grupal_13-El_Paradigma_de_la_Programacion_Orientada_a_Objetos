public class Main {

    /**
     * @author Bastián Mariángel
     * @author Roberto Rivas
     * @author Patricio Bonnin
     * @author Ivan Mieres
     * */

    public static void main(String[] args){

        // Crear objetos
        Usuario usuario = new Usuario("Patricio","1800",99999);
        Cliente cliente = new Cliente(20700200,"Pedro","Muñoz",987654321,"Capital",1,"calle 3","Santiago",27);
        Capacitacion capacitacion = new Capacitacion(1, 99999, "2023-07-16", "14:00", "Santiago", 2, 20);

        // Mostrar datos
        System.out.println(usuario.toString());
        System.out.println(cliente.toString());
        System.out.println(capacitacion.toString());

    }


}
