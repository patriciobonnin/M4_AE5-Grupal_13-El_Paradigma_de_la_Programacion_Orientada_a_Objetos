public class Usuario {


    private String nombre;
    private String fechaNacimiento;
    private int run;


    public Usuario() {
        this.nombre = "";
        this.fechaNacimiento = "";
        this.run = 0;
    }

    public Usuario(String nombre, String fechaNacimiento, int run) {
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.run = run;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "nombre='" + nombre + '\'' +
                ", fechaNacimiento='" + fechaNacimiento + '\'' +
                ", run=" + run +
                '}';
    }
}
